/*
  HF-RISC Unit Testing framework

  edit these macros to chage the behavior of HF-UNIT.
  See usage examples in the dir software/tests
*/
#include <hf-unit.h>
#include <hf-risc.h>


// =======================
// util functions
// =======================
void printBits(size_t const size, void const * const ptr)
{
    unsigned char *b = (unsigned char*) ptr;
    unsigned char byte;
    int i, j;

    for (i=size-1;i>=0;i--)
    {
        for (j=7;j>=0;j--)
        {
            byte = (b[i] >> j) & 1;
            printf("%u", byte);
        }
    }
    puts("");
}

// teste strtol
/*int32_t strtol(const int8_t *s, int8_t **end, int32_t base){
	int32_t i;
	uint32_t ch, value=0, neg=0;

	if(s[0] == '-'){
		neg = 1;
		++s;
	}
	if(s[0] == '0' && s[1] == 'x'){
		base = 16;
		s += 2;
	}
	for(i = 0; i <= 8; ++i){
		ch = *s++;
		if('0' <= ch && ch <= '9')
			ch -= '0';
		else if('A' <= ch && ch <= 'Z')
			ch = ch - 'A' + 10;
		else if('a' <= ch && ch <= 'z')
			ch = ch - 'a' + 10;
		else
			break;
		value = value * base + ch;
	}
	if(end)
		*end = (char*)s - 1;
	if(neg)
		value = -(int32_t)value;
	return value;
}

// teste do logaritmo
float log(float arg){
	static float p0	= -0.240139179559210510e2f;
	static float p1	=  0.309572928215376501e2f;
	static float p2	= -0.963769093368686593e1f;
	static float p3	=  0.421087371217979714e0f;
	static float q0	= -0.120069589779605255e2f;
	static float q1	=  0.194809660700889731e2f;
	static float q2	= -0.891110902798312337e1f;

	float x,z, zsq, temp;
	int32_t exp;

	if(arg <= 0.0f){
		return(-HUGE);
	}
	x = frexp(arg,&exp);
	while(x < 0.5f){
		x *= 2.0f;
		exp--;
	}
	if(x < SQRT1_2){
		x *= 2.0f;
		exp--;
	}

	z = (x-1.0f)/(x+1.0f);
	zsq = z*z;

	temp = ((p3*zsq + p2)*zsq + p1)*zsq + p0;
	temp = temp/(((1.0f*zsq + q2)*zsq + q1)*zsq + q0);
	temp = temp*z + exp*LN2;
	return(temp);
}

// matriz identidade
struct Matrix setEye(int order)
{

  struct Matrix out;
  out.line = order;
  out.column = order;

	for (int i = 0; i < order; i++){
		for (int j = 0; j < order; j++){
			if (j == i){
				out.str[i][j] = val(1);
			}
			else{
				out.str[i][j] = val(0);
			}
		}
	}

    return out;

}

fixed_t fix_log(fixed_t fp, fixed_t base)
{
	return fix_div(fix_ln(fp), fix_ln(base));
}*/




// =======================
// comparison functions
// =======================

// compare int/char/short vectors. do not use this for vector of float or double. it wont work !
int hfunit_comp_vector(void *v1,void *v2, int size, char* message){
	test_counter++;
	if (memcmp(v1,v2,size)!=0){
		failed_tests++;
		HFUNIT_MSG_FAIL(message)
		return 1;
	}else{
		HFUNIT_MSG_PASS(message)
		return 0;
	}
}

// compare floats
int hfunit_comp_float(float f1,float f2, char *message){
	test_counter++;
	if (!(((f1 - HFUNIT_PRECISION) < f2) && ((f1 + HFUNIT_PRECISION) > f2)))
	{
		failed_tests++;
		HFUNIT_MSG_FAIL(message)
		return 1;
	}else{
		HFUNIT_MSG_PASS(message)
		return 0;
	}
}
