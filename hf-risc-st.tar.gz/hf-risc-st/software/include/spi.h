void spi_setup(void);
void spi_start(void);
void spi_stop(void);
int8_t spi_transfer(int8_t data);
