/*
This matrix lib can work with 3 different types: fixed, float, and double.
just change the variable MATRIX_TYPE in the makefile
*/

#include <mat_type.h> // this include define the type of the matrix
#include <matrix.h>   // the functions under test are defined here
#include <hf-risc.h>
#include <hf-unit.h>

// função testada sera a matriz identidade, onde se i=j ,deve-se ser 1, caso contrario 0
struct Matrix setEye(int order);

// Lista de testes 
/* CLASSES DE EQUIVALENCIA
   Entrada 		 			 		Classes Válidas 			 Classes Inválidas
   Seta '1' caso i=j         		i=j   						 i!=j
   
   Indice(i) deve ser menor 
   ou igual ao tamanho da linha 	1<=i<=m					     i>m
   
   Indice(j) deve ser menor 
   ou igual ao tamanho da coluna    1<=j<=n					     j>n

  CASOS DE TESTE DE EQUIVALENCIA
  Seta '1' caso i=j				 Indice(i) deve ser menor ou igual ao tamanho da linha				Indice(j) deve ser menor ou igual ao tamanho da coluna	 			Saida esperada
  i=1 e j=2		  				 -																	-																	0
  i=1 e j=1						 -																	-																	1
  i=4 e m=3		                 -																	-																	Erro: indice deve ser menor ou igual ao tamanho da linha
  j=4 e n=3		                 -																	-																	Erro: indice deve ser menor ou igual ao tamanho da coluna
  -		                 		 i=1 e m=3															-																	-
  -		                 		 -																    j=1 e m=3														    -

  CASOS DE TESTE VALOR LIMITE
  Seta '1' caso i=j				 Indice(i) deve ser menor ou igual ao tamanho da linha				Indice(j) deve ser menor ou igual ao tamanho da coluna	 			Saida esperada
  i=1 e j=2		  				 -																	-																	0
  i=1 e j=1						 -																	-																	1
  i=4 e m=3		                 -																	-																	Erro: indice deve ser menor ou igual ao tamanho da linha
  j=4 e n=3		                 -																	-																	Erro: indice deve ser menor ou igual ao tamanho da coluna
  -		                 		 i=1 e m=3															-																	-
  -		                 		 -																    j=1 e m=3														    -


    1 0 0 
M = 0 1 0
	0 0 1
	
*Matriz 3x3, onde m e n são iguais a 3	

*/

// lista de testes
void teste1();
void teste2();
void teste3();


// main tests
void hfunit_run_tests(){
	teste1();
	teste2();
	teste3();

}
//printa matriz identidade de tamanho 3, onde i=j, deve funcionar
void teste1() {

struct Matrix M1;

printf("Identity Matrix of size %d by %d:\n", 3, 3);
M1 = setEye(3);
print_matrix(M1);

}

//printa matriz identidade de tamanho 3, onde i!=j, deve funcionar mas nao sera uma matriz identidade
void teste2() {

struct Matrix M1;

printf("Identity Matrix of size %d by %d:\n", 3, 4);
M1 = setEye(3);
print_matrix(M1);

}


//printa matriz identidade de tamanho 3, onde i>m ,deve ocorrer erro
void teste3() {

struct Matrix M1;

printf("Identity Matrix of size %d by %d:\n", 4, 3);
M1 = setEye(4);
print_matrix(M1);

}

