#include <hf-risc.h>
#include <hf-unit.h>

// funcao strtol ( converte string para inteiro )
int32_t strtol(const int8_t *s, int8_t **end, int32_t base);

// Lista de testes 
/* CLASSES DE EQUIVALENCIA
   Entrada 		 											Classes Válidas 						 Classes Inválidas
   Tamanho da base que contem digitos/letras validas		0<=b<=36								 b<0 ou b>36
   
   Caso a base seja 0, pode ser necessario um sinal			b=0										 b!=0
   
   Caso a base seja 16, pode ser necessario adicionar 		b=16									 b!=16
   o prefixo "0x" ou "0X 
   
   Uma sequência de dígitos decimais 						b = NULL								 b!= NULL
   (se nenhum prefixo base foi especificado) 


   CASOS DE TESTE DE EQUIVALENCIA
   Tamanho da base que contem digitos/letras validas 	- 		Caso a base seja 0, pode ser necessario um sinal 		- 		Caso a base seja 16, pode ser necessario adicionar o prefixo "0x" ou "0X		-		 Uma sequência de dígitos decimais (se nenhum prefixo base foi especificado)		-		Saida esperada
   b=-8															-																-																						 -																							Erro: Digito ou letra deve ser maior ou igual a 0
   b=56															-																-																						 -																							Erro: Digito ou letra deve ser menor ou igual a 36
   b=4															-																-																						 -																							4
   b=0															b=0																-																						 -																							Sinal de + ou - 
   b=16															-																b=16																					 -																							Adicionado prefixo "0x" ou "0X"
   b=NULL														-																-																						 b=NULL																						Sequencia de digitos decimais
  
  CASOS DE TESTE VALOR LIMITE
   Tamanho da base que contem digitos/letras validas 	- 		Caso a base seja 0, pode ser necessario um sinal 		- 		Caso a base seja 16, pode ser necessario adicionar o prefixo "0x" ou "0X		-		 Uma sequência de dígitos decimais (se nenhum prefixo base foi especificado)		-		Saida esperada
   b=-1															-																-																						 -																							Erro: Digito ou letra deve ser maior ou igual a 0
   b=37															-																-																						 -																							Erro: Digito ou letra deve ser menor ou igual a 36
   b=1															-																-																						 -																							1
   b=36															-																-																						 -																							Z
   b=0															b=0																-																						 -																							Sinal de + ou - 
   b=16															-																b=16																					 -																							Adicionado prefixo "0x" ou "0X"
   b=NULL														-																-																						 b=NULL																						Sequencia de digitos decimais					
*/

// testes
void teste1(); // testa base negativa
void teste2();
void teste3();
void teste4();
void teste5();
void teste6();


// main test
void hfunit_run_tests(){
	teste1();
	teste2();
	teste3();
	teste4();
	teste5();
	teste6();
}

// testa com uma base negativa, deve acusar erro
void teste1(){
	/* Define temporary variables */
    char value[10];
    char *eptr;
    long result;
	
	/* Copy a value into the variable */
    /* It's okay to have whitespace before the number */
    strcpy(value, " 123");

    /* Convert the provided value to a decimal long */
    result = strtol(value, &eptr, -8);
	
	/* Display the converted result */
    printf("%ld decimal\n", result);
}

// testa com base maior que 32 ( deve falhar )
void teste2(){
	/* Define temporary variables */
    char value[10];
    char *eptr;
    long result;
	
	/* Copy a value into the variable */
    /* It's okay to have whitespace before the number */
    strcpy(value, " 123");

    /* Convert the provided value to a decimal long */
    result = strtol(value, &eptr, 56);
	
	/* Display the converted result */
    printf("%d decimal\n", result);
}

// testa com base=4 ( deve funcionar )
void teste3(){
/* Define temporary variables */
    char value[10];
    char *eptr;
    long result;
	
	/* Copy a value into the variable */
    /* It's okay to have whitespace before the number */
    strcpy(value, " 123");

    /* Convert the provided value to a decimal long */
    result = strtol(value, &eptr, 4);
	
	/* Display the converted result */
    printf("%ld decimal\n", result);
}

// testa com base=0
void teste4(){
	/* Define temporary variables */
    char value[10];
    char *eptr;
    long result;
	
	/* Copy a value into the variable */
    /* It's okay to have whitespace before the number */
    strcpy(value, " 123");

    /* Convert the provided value to a decimal long */
    result = strtol(value, &eptr, 0);
	
	/* Display the converted result */
    printf("%ld decimal\n", result);
}

// testa com base=16
void teste5(){
	/* Define temporary variables */
    char value[10];
    char *eptr;
    long result;
	
	/* Copy a value into the variable */
    /* It's okay to have whitespace before the number */
    strcpy(value, " 123");

    /* Convert the provided value to a decimal long */
    result = strtol(value, &eptr, 16);
	
	/* Display the converted result */
    printf("%ld decimal\n", result);
}

// testa com base=NULL
void teste6(){
	/* Define temporary variables */
    char value[10];
    char *eptr;
    long result;
	
	/* Copy a value into the variable */
    /* It's okay to have whitespace before the number */
    strcpy(value, " 123");

    /* Convert the provided value to a decimal long */
    result = strtol(value, &eptr, NULL);
	
	/* Display the converted result */
    printf("%ld decimal\n", result);
}




