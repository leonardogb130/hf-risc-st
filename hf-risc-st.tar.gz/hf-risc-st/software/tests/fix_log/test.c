#include <hf-risc.h>
#include <hf-unit.h>
#include <fixed.h>

float log(float arg){
	static float p0	= -0.240139179559210510e2f;
	static float p1	=  0.309572928215376501e2f;
	static float p2	= -0.963769093368686593e1f;
	static float p3	=  0.421087371217979714e0f;
	static float q0	= -0.120069589779605255e2f;
	static float q1	=  0.194809660700889731e2f;
	static float q2	= -0.891110902798312337e1f;

	float x,z, zsq, temp;
	int32_t exp;

	if(arg <= 0.0f){
		return(-HUGE);
	}
	x = frexp(arg,&exp);
	while(x < 0.5f){
		x *= 2.0f;
		exp--;
	}
	if(x < SQRT1_2){
		x *= 2.0f;
		exp--;
	}

	z = (x-1.0f)/(x+1.0f);
	zsq = z*z;

	temp = ((p3*zsq + p2)*zsq + p1)*zsq + p0;
	temp = temp/(((1.0f*zsq + q2)*zsq + q1)*zsq + q0);
	temp = temp*z + exp*LN2;
	return(temp);
}

// função testada sera a fix_logaritmo
fixed_t fix_log(fixed_t fp, fixed_t base)
{
	return fix_div(fix_ln(fp), fix_ln(base));
}


int main()
{
	/* volatile is being used to avoid the optimizer from being too smart */
	
	volatile float fpfl = 1.0;
	volatile float basefl = 1.9E38;
	
    float result;
	
	fixed_t fpfx = fix_val(fp);
	fixed_t basefx = fix_val(base);
		
	fixed_t result_x
	int8_t buf[20];
	
	printf("\nfloat / fixed point speed test\n");

	result = log(basefl);
	printf("resultado do log: %s\n", result);
	
	resultx = log(basefx);
	printf("resultado do log com fix: %s\n", resultx);

	return 0;
}
