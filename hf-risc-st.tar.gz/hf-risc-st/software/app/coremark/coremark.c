#include <hf-risc.h>

int main(){
	coremain();
	
	return 0;
}
